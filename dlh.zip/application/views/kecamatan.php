<?php
foreach($kecamatan as $k){ ?>
<option value="<?php echo $k['nama_kecamatan'] ?>"> <?php echo $k['nama_kecamatan'] ?> </option>
<?php } ?>