

    <section class="content">
      <div class="col-md-12">
        <div class="row">
        <div class="box box-success">
          <div class="box-header">
            <h3> Selamat Datang Di Sistem Borang Prodi UIN Syarif Hidayatullah Jakarta </h3>
          </div>
          <div class="box-body">
            <p> Silahkan bla.. </p>
          </div>
        </div>
        </div>
      </div>
    </section>  
