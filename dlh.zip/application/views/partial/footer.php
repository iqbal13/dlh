<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1
    </div>
    <strong>Copyright &copy; 2017 <a href="https://www.facebook.com/maulana.iqbal.35" target="_blank">Sistem Manajemen TPS </a>. Developed by: <a href="https://www.facebook.com/maulana.iqbal.35" target="_blank"> Maulana Iqbal </a></strong> All rights
    reserved.
  </footer>